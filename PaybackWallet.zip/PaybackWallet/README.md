# PaybackWallet

Minimal Android Studio project (Kotlin) for scanning loyalty cards and storing them locally.

Open this folder in Android Studio.
